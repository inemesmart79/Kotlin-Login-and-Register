package simplifiedcoding.net.kotlinretrofittutorial.models

import com.google.gson.annotations.SerializedName

data class DefaultResponse(val error: Boolean, val message:String)